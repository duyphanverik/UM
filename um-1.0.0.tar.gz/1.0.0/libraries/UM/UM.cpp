#include "UM.h"

UMClass UM;


UMClass::UMClass()
{

}

void UMClass::begin()
{
	
}

void UMClass::end() 
{
	
}

int UMClass::sendUMData(byte *data, size_t size)
{
	spi.begin();
	spi.transferBuff(data, size);
	spi.end();
}


